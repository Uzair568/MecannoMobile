using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class check : MonoBehaviour
{

    private void Start()
    {
        Debug.Log("started!");
    }

    void OnCollisionEnter(Collision collision)
    {

        Debug.Log("in coll!");
        if (collision.gameObject.tag == "tyre")
        {
            Destroy(collision.gameObject);
        }
        Debug.Log("Collided with :"  + collision.gameObject.name);



        if(collision.gameObject.tag == "7holes")
        {
            Debug.Log("Collided with 7 holes!");
        }

    }






}

